/*
 * V7 detector placeholder.
 *
 * V6.3 remains untouched in legacy/v6.3-stable.js.
 * In the next stage we will move the proven V6.3 local detection logic here,
 * function-for-function, with tests before changing behavior.
 */
export const DETECTOR_VERSION = "v7-detector-bootstrap";
